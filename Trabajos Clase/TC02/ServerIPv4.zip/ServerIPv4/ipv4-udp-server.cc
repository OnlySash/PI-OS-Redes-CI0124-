/**
  *  Universidad de Costa Rica
  *  ECCI
  *  CI0123 Proyecto integrador de redes y sistemas operativos
  *  2026-ii
  *  Grupos: 2 y 5
  *
  ****** Socket class interface
  *
  * (Fedora version)
  *
  *  Server-side implementation of UDP client-server model	
  *
 **/

#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "VSocket.h" 
#include "Socket.h" 

#define PORT	1234 
#define MAXLINE 1024 

int main() { 
   VSocket * server;
   int len, n; 
   int sockfd;
   struct sockaddr_in other;
   char buffer[MAXLINE]; 
   char *hello = (char *) "Hello 2026-ii from CI0123 server"; 
	
   server = new Socket( 'd', false );
   server->Bind( PORT );

   memset( &other, 0, sizeof( other ) );

   n = server->recvFrom( (void *) buffer, MAXLINE-1, (void *) &other );	
   buffer[n] = '\0'; 
   printf("Server: message received: %s\n", buffer);

   server->sendTo( (const void *) hello, strlen( hello ), (void *) &other );
   printf("Server: Hello message sent.\n"); 

   server->Close();
   
   return 0;

} 

